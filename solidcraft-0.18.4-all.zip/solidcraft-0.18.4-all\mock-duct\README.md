# Mock part-cooling duct

A made-up duct for trying Airflow studies, nothing from a real printer:

- a 40 × 40 mm fan plenum (12 mm deep, open on top for the fan)
- a 40 mm channel ending in a 24 × 6 mm slot
- a nozzle (8 mm cylinder) in front of the slot
- a bed 3 mm below

The study **Part cooling** is saved beside it in `mock-part-cooling-duct.sim.json`:

- inlet: a 4010 axial fan (6 CFM free air, 70 Pa max) across the plenum's top
- outlet: Slot
- cells: 0.8 mm; 10 mm of open air around

## Run it

Open `mock-part-cooling-duct.solidcraft`, go to Simulation, pick **Part cooling** and Run. Or from a terminal:

    solidcraft-cli run run.json --results --json-out run_out.json

## What to expect

Measured on an RTX 4070 laptop GPU: 1.39 million cells, about 7½ minutes.

- Fan: about **1.68 CFM at 47 Pa**.
- Slot: the same 1.68 CFM, 5.9 m/s on average and 9.5 m/s at the fastest.

The run ends at the step limit rather than settled, because the jet hitting the nozzle keeps flickering; the flows are steady to four figures.

## Things to try

- Change the slot (the 4th box in the timeline, its width and height) and run again.
- Set the fan to a radial blower with a higher max pressure. A 4010 axial is weak against a slot this small.
- Use Goal Seek to vary a parameter and maximize the flow at the slot.

`build.json` rebuilds the design and the study from scratch.
