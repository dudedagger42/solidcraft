# Sprint test list: SolidCraft 0.18.2 + bug fixes + QOL + simulation

**App:** `B:\Claude\build-for-work\solidcraft-0.18.2-sprint\solidcraft.exe`
**Branch:** `try-0.18.2` = `qol` + `bugfixes` + `simulation-0.18`, all on upstream 0.18.2 (released last night).
**Mock duct to test:** `B:\Claude\build-for-work\mock-duct\` (see its README).

Each item: what it did before, what it should do now. Tick it, or note what you saw.

## Bug fixes

- [ ] **Same constraint twice.** Put Parallel on two lines, then pick Parallel on the same two again.
  - *Before:* a second Parallel glyph stacked on the first.
  - *Now:* still one glyph; the status line says it's redundant.
- [ ] **Arc radius text.** Draw a 3-point arc low on the left, then dimension its radius.
  - *Before:* the text sat at 45° up and to the right of the centre, off the arc.
  - *Now:* it sits at the arc's middle.
- [ ] **Offset a rectangle drawn line by line.** Draw 4 separate lines into a closed rectangle, then Offset 2 mm.
  - *Before:* each line offset on its own; both horizontals moved up and the shape came apart.
  - *Now:* one closed rectangle, 2 mm out (or in).
- [ ] **Click through see-through bodies.** Make a body see-through, or switch to Shaded with Hidden Edges, then click an edge behind it.
  - *Before:* the body in front swallowed the click.
  - *Now:* the edge is picked. On an opaque body, hold still ½ s (or right-click › Select Other…) to list what's underneath.
- [ ] **T-shape chamfer (#4055).** Cylinder r 8, height 30; box 100 × 20 × 15 on top, joined; chamfer the box's bottom long edge by 3 mm. Repeat with 2.5 and 5 mm.
  - *Before:* 2.5 and 3 mm left a hole where the chamfer met the pin; 4 and 5 mm were refused.
  - *Now:* closed parts, the pin whole, and 5 mm builds. A section through x = 0 shows the pin's top bared as a small ledge.
  - Known: 4 mm on this pin builds with the right volume, but one seam on the pin is doubled. A slicer won't mind, but tell me if anything looks off.

- [ ] **Drag over a floating card.** In a sketch, drag a line's end slowly onto the sketch palette (or the navigator) and let go there.
  - *Before:* the point stopped at the card's edge, the moment the pointer crossed it.
  - *Now:* it follows the pointer under the card and ends where you let go. Triad arrows and dimensions too. Starting a new drag on a card still does nothing to the model.

## Quality of life

- [ ] **⋯ on drop-down rows (pin removed).** Open any toolbar drop-down.
  - *Before:* a pin icon on each row (and, in the last test build, a ⋯ beside it).
  - *Now:* just ⋯ at the row's end. Its menu has Pin to Toolbar / Remove, Pin to Shortcuts, **Change Keyboard Shortcut…** (Preferences opens on that command, waiting for a key) and Customize Toolbar. The row shows the key you gave it.
- [ ] **Revolve about a circular edge.** Draw a profile beside a cylinder, then Revolve › Axis and click the cylinder's top circle.
  - *Before:* only a straight edge or a cylindrical face would do (and on upstream, neither).
  - *Now:* it revolves about the circle's axis. A cylindrical face and a straight edge also work.
- [ ] **Sketch keys vs model keys.** In a sketch, press F; outside one, press F.
  - *Before:* F started Fillet even while sketching.
  - *Now:* F does nothing in a sketch and is Fillet in the model. M is Move/Copy in a sketch and Move outside one.
- [ ] **Move/Copy triad.** Select sketch geometry, then Move/Copy.
  - *Before (last test build):* a single arrow that grew as you dragged.
  - *Now:* a fixed-size triad at the selection that travels with it: X and Y arrows (wider), the XY square, a free-drag ball and the Angle ring. A 3D sketch adds Z and the two upright squares.
  - Also check picking a rectangle's four sides one by one: the triad sits on what you've picked, and a click on a side under one of its handles should still pick the side. (Fixed tonight; a test caught it.)
- [ ] **3D sketch: free drag and lifting points.** Turn on 3D Sketch (Sketch palette › More), place a few points, then drag one.
  - *Before:* points on the plane could never leave it; in the last test build a click showed a triad.
  - *Now:* a drag moves it freely in the plane. Move/Copy's Z lifts picked points, lone points and copies off the plane, even in the straight-down view (Z is drawn up and to the left there). A lifted point can be picked and moved again.
- [ ] **Parts library.** File › Show Parts Library, then pick a folder.
  - *Before:* didn't exist.
  - *Now:* designs and STEP/STL parts list with pictures. Drag one into the view to insert it at the drop point, double-click a design to open it, and narrow the panel to a strip.

## New in 0.18.2 (upstream, worth a glance since our changes touch the same places)

- [ ] Ribbon tooltips show short help, and our ⋯ menu still works beside them.
- [ ] A quick double Esc finishes a sketch. It shouldn't fight the sketch/model keys.
- [ ] New Sketch is on the Surface and Sheet Metal tabs.

## Simulation (Airflow)

- [ ] **Open the mock duct.** `mock-duct\mock-part-cooling-duct.solidcraft`. The Simulation workspace should list the study **Part cooling**.
- [ ] **Run it.** Simulation › the study › Run.
  - *Expect:* about 7½ minutes on your 4070. It ends at **Step limit reached** rather than **Settled**: the jet hitting the nozzle keeps flickering. The numbers are steady anyway.
  - *Expect:* Fan 4010 at about **1.68 CFM, 47 Pa**, the same flow out of Slot (top speed about 9.5 m/s).
- [ ] **Look at it.** Show in the view: a Speed section through the slot's middle, then Streamlines. The jet should hit the nozzle and spread on the bed.
- [ ] **Your own duct (optional).** Rerun a duct study from before. *Before:* the fan was credited with more air than entered the duct (AIO: 5.9 CFM). *Now:* the fan sits on its curve; the AIO reads about 7.2 CFM (OpenFOAM says 9.96).
- [ ] **Smaller GPU (optional).** If you have a 4 GB card: the same study should run, with coarser cells if it needs them, instead of failing.

## Known, not ours

- Nothing new: the floating-card drag stop is fixed above.
