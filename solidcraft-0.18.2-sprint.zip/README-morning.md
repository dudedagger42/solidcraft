# Morning summary (2026-10-21)

## Before testing: reboot
By 05:30 the RTX 4070 had stopped answering. `nvidia-smi` says "No devices were found", and the GPU list shows only the Intel graphics, though Device Manager still lists the card as OK. A reboot should bring it back. Until then studies run on the Intel GPU: the mock duct took 93 minutes there instead of 7½, with the same result. Check with `solidcraft-cli gpu`: the line that names the adapter it picked should name the RTX 4070.

I can't tell what caused it. Two things stressed the GPU tonight:
- two CI runs testing it at once;
- the new GPU memory probe, which allocates close to the card's full memory to see what fits.

If it happens again after a reboot, suspect the probe, and I'll make it gentler.

## Test first
- **App:** `B:\Claude\build-for-work\solidcraft-0.18.2-sprint\solidcraft.exe`. This is all three branches on upstream **0.18.2**, which came out last night.
- **Checklist:** `B:\Claude\build-for-work\sprint-test-list.md`, listing what each item did before and what it should do now.
- **Mock duct:** `B:\Claude\build-for-work\mock-duct\`. Open the `.solidcraft`, go to Simulation, and run **Part cooling**. It takes about 7½ minutes and should give about 1.68 CFM at 47 Pa.

## Branches on your fork (dudedagger42/solidcraft)
| branch | what | upstream `main` |
|---|---|---|
| `bugfixes` | 6 fixes, one commit each | merges cleanly |
| `qol` | 13 QOL commits | one conflict, in `sketch_shortcut_tests.rs` (keep both) |
| `simulation-0.18` | Airflow plus tonight's accuracy work | merges cleanly |
| `try-0.18.2` | the three combined, which is what the app is built from | — |

PR texts are in `B:\Claude\build-for-work\prs\`:
- `1-qol.md`
- `2-bugfixes.md`
- `3-simulation.md`
- `4-fieldcraft.md`

Nothing has been opened upstream; you publish them.

## Filed tonight
- tangency-labs/solidcraft#4055: chamfer over a joined pin. The fix is on `bugfixes`.
- tangency-labs/fieldcraft#663: a turbulence model for their LBM, with tonight's validation numbers.

## Simulation accuracy (50 mm pipe, 5 m/s)
- The textbook developing-flow correlation (Shah & London) and a resolved OpenFOAM run agree to 0.5%. The old OpenFOAM mesh, with no wall layers, was the one that was off.
- Ours against that reference: the mid-pipe pressure gradient is **−3%** and the inlet pressure **+8%**.
- Ducts against OpenFOAM:
  - Core One shroud: **−3%**;
  - AIO duct: **−28%**, up from −41%. That OpenFOAM run used the same quick mesh, so the gap may be partly OpenFOAM's.

## Not done
- **FieldCraft PR:** three commits are ready on a local branch (`B:\Claude\fieldcraft`, `lbm-smagorinsky`) but not pushed. Their rules want a maintainer reply on #663 first, plus a turbulent-channel benchmark; see `4-fieldcraft.md`.
- **Chamfer, 8 mm pin with a 4 mm chamfer:** the volume is right, but one doubled seam remains.
- **AIO duct gap:** needs a resolved OpenFOAM run of the duct to settle.
- **Bug-fix count:** six on `bugfixes`. The open UI bugs on GitHub were mostly already fixed in 0.18.x, designed that way, or not reproducible. The floating-card drag fix came from our own testing, and CI caught a Move/Copy pick problem in `qol`, now fixed there.
