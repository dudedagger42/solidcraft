@echo off
rem Starts SolidCraft with its control port open, so Claude (through solidcraft-cli mcp --connect 127.0.0.1:7878) can work in this window.
start "" "%~dp0solidcraft.exe" --control 7878
